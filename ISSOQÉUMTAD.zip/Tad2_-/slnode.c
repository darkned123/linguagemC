#define slnode_c
#include "slnode.h"
#include<stdio.h>
#include<stdlib.h>
#define TRUE 1
#define FALSE 0
/*Implementa��o das fun��es*/

sllist *sllCreate(void){

sllist *l;
        l = (sllist*) malloc (sizeof(sllist));
        if (l != NULL){
            l->first = NULL;
            return l;
        }
        return NULL;
}

void sllInsert(sllist *l , void *elem){

slnode *node;
      if(l!=NULL){
       node =(slnode*) malloc (sizeof(slnode));
       if ( node != NULL ){
            node->data = elem;
            if (l->first == NULL){
                node->next = NULL;
                l->first = node;
            }else{
                  node->next = l->first;
                  l->first = node;
                  }
       }
      }
}


void *sllRemoveFirst(sllist *l){

void *elem;
slnode *node;
     node =(slnode*) malloc (sizeof(slnode));
     if (node != NULL){
         if (l != NULL){
             if (l->first != NULL){
                 elem = l->first->data;
                 node = l->first;
                 l->first = node->next;
                 free(node);
                 return elem;
             }
         }
     }
   return NULL;
}

int sllDestroy(sllist *l){

 if(l != NULL){
      if (l->first != NULL){
          free(l);
          return TRUE;
      }
 }
 return FALSE;
}


