#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "slnode.h"
#define TRUE 1
#define FALSE 0

int main (){

char *string;
sllist *l;
int n,i;
int estado = TRUE;
void *valor;


    string = (char*) malloc (sizeof(char));

    if (string != NULL){
        l = sllCreate();
        if ( l != NULL){
            printf("Digite o nome:");
            gets(string);
            n = strlen(string);
            for(i=0;i<n;i++){
               // if(string[i] != ' ')
                   sllInsert(l ,string[i]);
            }
            for (i=0;i<n;i++){
                if(string[i]==' ')
                {

                    continue;


                }
                valor = sllRemoveFirst(l);
                if(valor==' ')
                {
                    --i;
                    continue;

                }

                if(string[i] != valor ){

                estado = FALSE;
                }
            }
            if (estado == TRUE){
                printf("Palindromo\n");
            }else printf("Nao e um palindromo\n");
            sllDestroy(l);
        }
    }
    system("PAUSE");
}
