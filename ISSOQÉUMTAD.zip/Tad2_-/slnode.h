/*------------------------------------------------------------------
slnode.h                                                           -
Arquivo.h com a especifica��o para o TAD( Tipo Abstrato de Dado)   -
Lista como Pilha
Palindromos                                         -
-----------------------------------------------------------------*/
#ifndef slnode_h
    #define slnode_h
#endif
#include <stdio.h>
#include <stdlib.h>
typedef struct _slnode_{
        void *data;
        struct _slnode_ *next; /* aponta para a proxima estrutura */
}slnode;


typedef struct _sllist_{
        slnode *first;
}sllist;
#ifndef slnode_c

sllist *sllCreate(void);

int sllDestroy(sllist *l);


void sllInsert(sllist *l , void *elem);


void *sllRemoveFirst(sllist *l);



#else
extern sllist *sllCreate(void);

extern int sllDestroy(sllist *l);

extern void sllInsert(sllist *l , void *elem);

extern void *sllRemoveFirst(sllist *l);


#endif
